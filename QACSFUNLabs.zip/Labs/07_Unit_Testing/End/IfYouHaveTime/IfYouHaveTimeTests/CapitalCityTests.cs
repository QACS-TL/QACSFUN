﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Conditionals;

namespace IfYouHaveTimeTests
{
    public class CapitalCityTests
    {
        [Fact]
        public void FranceTest()
        {
            //Arrange
            CapitalCities city = CapitalCities.Paris;

            string countryMessage;
            string expectedCountryMessage = $"{city} is the capital of France";

            //Act
            countryMessage = Program.GetCountryForCapitalCity(city);

            //Assert
            Assert.Equal(expectedCountryMessage, countryMessage);
        }

        [Fact]
        public void MadridTest()
        {
            //Arrange
            CapitalCities city = CapitalCities.Madrid;

            string countryMessage;
            string expectedCountryMessage = $"{city} is the capital of Spain";

            //Act
            countryMessage = Program.GetCountryForCapitalCity(city);

            //Assert
            Assert.Equal(expectedCountryMessage, countryMessage);
        }

        [Fact]
        public void UnknownCapitalCityTest()
        {
            //Arrange
            CapitalCities city = (CapitalCities)6;

            string countryMessage;
            string expectedCountryMessage = $"{city} is not a known capital city";

            //Act
            countryMessage = Program.GetCountryForCapitalCity(city);

            //Assert
            Assert.Equal(expectedCountryMessage, countryMessage);
        }
    }
}
