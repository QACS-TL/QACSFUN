﻿using Xunit;
using CoffeeShop;

namespace CoffeeShopTests
{
    public class OrderTests
    {
        [Fact]
        public void AddDrink_ShouldIncreaseCount()
        {
            var order = new Order();
            var drink = new Drink("Latte", 3.50m);

            order.AddDrink(drink);

            Assert.Single(order.Drinks);
        }

        [Fact]
        public void GetTotal_ShouldReturnCorrectSum()
        {
            var order = new Order();
            order.AddDrink(new Drink("Espresso", 2.50m));
            order.AddDrink(new Drink("Latte", 3.50m));

            var total = order.GetTotal();

            Assert.Equal(6.00m, total);
        }

        [Fact]
        public void GetTotal_EmptyOrder_ShouldBeZero()
        {
            var order = new Order();

            var total = order.GetTotal();

            Assert.Equal(0.00m, total);
        }
    }
}
