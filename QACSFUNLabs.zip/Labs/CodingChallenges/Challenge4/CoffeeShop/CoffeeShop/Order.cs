﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoffeeShop
{
    public class Order
    {
        private readonly List<Drink> _drinks = new List<Drink>();

        public IReadOnlyList<Drink> Drinks => _drinks;

        public void AddDrink(Drink drink)
        {
            _drinks.Add(drink);
        }

        public decimal GetTotal()
        {
            return _drinks.Sum(d => d.Price);
        }
    }
}
