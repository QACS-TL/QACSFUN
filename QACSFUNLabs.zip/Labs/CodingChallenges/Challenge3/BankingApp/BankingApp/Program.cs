﻿
//using System.ComponentModel.Design;

//namespace BankingApp
//{
//    public class Program
//    {

//        public static void Main()
//        {
//            Dictionary<string, Tuple<string, string, decimal>> accounts = CreateAccounts();
//            string accountNumber = LogIn(accounts);
//            if (accountNumber == null)
//            {
//                Console.WriteLine("Invalid Credentials. Program terminating");
//                return;
//            }

//            decimal balance = accounts[accountNumber].Item3;
//            //Get Balance
//            Console.WriteLine(GetFormattedBalance(balance));
//            while(true) { 
//            string selection = Menu();
//                switch (selection)
//                {
//                    case "1":
//                        Console.WriteLine(GetFormattedBalance(balance));
//                        break;
//                    //Credit
//                    case "2":
//                        decimal amount = Prompt("credit");
//                        if (amount > 0.00M)
//                        {
//                            balance = Credit(balance, amount);
//                            Console.WriteLine(GetFormattedBalance(balance));
//                        }
//                        break;
//                    //Debit
//                    case "3":
//                        amount = Prompt("debit");
//                        if (amount > 0.00M)
//                        {
//                            balance = Debit(balance, amount);
//                            Console.WriteLine(GetFormattedBalance(balance));
//                        }
//                        break;
//                    case "q":
//                    case "Q":
//                        Console.WriteLine("Program Terminated");
//                        return;
//                    default:
//                        Console.WriteLine("Invalid choice");
//                        break;
//                }
//            }

//        }

//        public static string Menu()
//        {
//            string menuText =
//                "Welcome to QA Banking\n"
//                + "Enter:\n"
//                + " 1 for Balance\n"
//                + " 2 to Credit\n"
//                + " 3 to Debit\n"
//                + "or 'Q' to quit";
//            Console.WriteLine(menuText);
//            string selection = Console.ReadLine();
//            return selection;
//        }

//        public static decimal Prompt(string promptText)
//        {
//            Console.WriteLine($"Please enter the amount you would like to {promptText}");
//            string amountAsString = Console.ReadLine();
//            if (amountAsString.ToLower() == "q")
//            {
//                return -1M;
//            }
//            decimal amount;
//            bool canConvert = decimal.TryParse(amountAsString, out amount);
//            while (!canConvert || amount < 0)
//            {
//                Console.WriteLine("Amounts must be numeric and cannot be negative. unless you enter 'q' to quit ");
//                amountAsString = Console.ReadLine();
//                if (amountAsString.ToLower() == "q")
//                {
//                    return -1M;
//                }
//                canConvert = decimal.TryParse(amountAsString, out amount);
//            }
//            return amount;
//        }

//        public static string GetFormattedBalance(decimal balance)
//        {
//            return $"Your current balance is {balance:C2}";
//        }

//        public static decimal Credit(decimal balance, decimal value)
//        {
//            return balance += value;
//        }

//        public static decimal Debit(decimal balance, decimal value)
//        {
//            return balance -= value;
//        }

//        public static string LogIn(Dictionary<string, Tuple<string, string, decimal>> accounts)
//        {
//            Console.WriteLine("Please enter your account number");
//            string accountNumber = Console.ReadLine();
//            //see if account number is valid
//            int count = 1;
//            while (!accounts.ContainsKey(accountNumber) && count < 3)
//            {
//                Console.WriteLine("Invalid Account number. Please try entering your account number again:");
//                accountNumber = Console.ReadLine();
//                count++;
//            }
//            if (!accounts.ContainsKey(accountNumber))
//            {
//                return null;
//            }

//            //PIN test
//            Console.WriteLine("Please enter your PIN");
//            string pin = Console.ReadLine();
//            //see if account number is valid
//            count = 1;
//            while ((accounts[accountNumber]).Item2 != pin && count < 3 )
//            {
//                Console.WriteLine("Invalid PIN number. Please try entering your PIN again:");
//                pin = Console.ReadLine();
//                count++;
//            }
//            if ((accounts[accountNumber]).Item2 == pin)
//            {
//                return accountNumber;
//            }
//            else
//            {
//                return null;
//            }
//        }

//        public static Dictionary<string, Tuple<string, string, decimal>> CreateAccounts()
//        {
//            //Tuple structure: accountNumber, PIN, Balance
//            Dictionary<string, Tuple<string, string, decimal>> accounts = new Dictionary<string, Tuple<string, string, decimal>>();
//            accounts.Add("111111", Tuple.Create("111111", "1234", 50.01M));
//            accounts.Add("222222", Tuple.Create("222222", "4321", 0.00M));
//            accounts.Add("333333", Tuple.Create("222222", "1212", 20.50M));
//            accounts.Add("444444", Tuple.Create("222222", "2345", 250.00M));
//            return accounts;
//        }
     
//    }
//}
