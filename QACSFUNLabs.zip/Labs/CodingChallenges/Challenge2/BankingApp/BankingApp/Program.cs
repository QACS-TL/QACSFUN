﻿
using System.ComponentModel.Design;

namespace BankingApp
{
    public class Program
    {

        public static void Main()
        {
            decimal balance = 0.00M;
            //Get Balance
            Console.WriteLine(GetFormattedBalance(balance));
            string selection = Menu();
            switch (selection) {
                case "1":
                    Console.WriteLine(GetFormattedBalance(balance));
                    break;
                //Credit
                case "2":
                    decimal amount = Prompt("credit");
                    balance = Credit(balance, amount);
                    Console.WriteLine(GetFormattedBalance(balance));
                    break;

                //Debit
                case "3":
                    amount = Prompt("debit");
                    balance = Debit(balance, amount);
                    Console.WriteLine(GetFormattedBalance(balance));
                    break;
                case "q":case "Q":
                    break;
                default:
                    Console.WriteLine("Invalid choice");
                    break;
            }

        }

        public static string Menu()
        {
            string menuText =
                "Welcome to QA Banking\n"
                + "Enter:\n"
                + " 1 for Balance\n"
                + " 2 to Credit\n"
                + " 3 to Debit\n"
                + "or 'Q' to quit";
            Console.WriteLine(menuText);
            string selection = Console.ReadLine();
            return selection;
        }

        public static decimal Prompt(string promptText)
        {
            Console.WriteLine($"Please enter the amount you would like to {promptText}");
            string amountAsString = Console.ReadLine();
            decimal amount = decimal.Parse(amountAsString);
            if (amount < 0) {
                Console.WriteLine("Amounts cannot be negative. £0.00 assumed");
                amount = 0.00M;
            }
            return amount;
        }

        public static string GetFormattedBalance(decimal balance)
        {
            return $"Your current balance is {balance:C2}";
        }

        public static decimal Credit(decimal balance, decimal value)
        {
            return balance += value;
        }

        public static decimal Debit(decimal balance, decimal value)
        {
            return balance -= value;
        }

     
    }
}
