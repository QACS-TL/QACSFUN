﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Challenge5Tasky
{
    public class TaskManager
    {
        private readonly List<TaskItem> _tasks = new();

        public IReadOnlyList<TaskItem> Tasks => _tasks;

        public TaskItem Add(string description, DateTime deadline, Priority priority)
        {
            var task = new TaskItem(description, deadline, priority);
            _tasks.Add(task);
            return task;
        }

        public bool Remove(int id)
        {
            var t = _tasks.FirstOrDefault(x => x.Id == id);
            if (t is null) return false;
            _tasks.Remove(t);
            return true;
        }

        public bool MarkComplete(int id)
        {
            var t = _tasks.FirstOrDefault(x => x.Id == id);
            if (t is null) return false;
            t.MarkComplete();
            return true;
        }

        public bool Edit(int id, string? description = null, DateTime? deadline = null, Priority? priority = null)
        {
            var t = _tasks.FirstOrDefault(x => x.Id == id);
            if (t is null) return false;

            t.EditTask(description, deadline, priority);
            return true;
        }

        public IEnumerable<TaskItem> SortedByPriorityDesc()
            => _tasks.OrderByDescending(t => t.Priority).ThenBy(t => t.Id);
    }

}
