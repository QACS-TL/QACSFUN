﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Challenge4
{
    public enum Priority { Low, Medium, High }

    public class TaskItem
    {
        private static int _nextId = 1;

        public int Id { get; }
        public string Description { get; private set; }
        public Priority Priority { get; private set; }
        public DateTime Deadline { get; private set; }
        public bool IsCompleted { get; private set; }

        public TaskItem(string description, DateTime deadline, Priority priority)
        {
            Id = _nextId++;
            Description = string.IsNullOrWhiteSpace(description)
                ? throw new ArgumentException("Description cannot be empty.")
                : description.Trim();
            Deadline = deadline;
            Priority = priority;
            IsCompleted = false;
        }

        public void MarkComplete() => IsCompleted = true;

        public void EditTask(string? newDescription = null, DateTime? newDeadline = null, Priority? newPriority = null)
        {
            if (newDescription is not null && newDescription != "")
            {
                Description = newDescription.Trim();
            }
            if (newDeadline is not null && newDeadline != default(DateTime))
                Deadline = newDeadline.Value;
            if (newPriority is not null)
                Priority = newPriority.Value;
        }


        string BuildPriorityMessage(int id, string description, DateTime deadline, Priority priority, bool isCompleted)
        {
            // priority is expected to be Low/Medium/High
            string partMessage = $" {description} by {deadline:ddd dd MMM yyyy} - {(isCompleted ? "Completed" : "Not Completed")}";
            return priority switch
            {
                Priority.High => $"{id}. ALERT: High-priority task: {partMessage}",
                Priority.Medium => $"{id}. Medium-priority task: {partMessage}",
                Priority.Low => $"{id}. Low-priority task: {partMessage}"
            };
        }

        public override string ToString()
            => BuildPriorityMessage(id: Id, description: Description, deadline: Deadline, priority: Priority, isCompleted: IsCompleted);
    }
}
