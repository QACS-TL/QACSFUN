﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Finance
{
    public class Account
    {

        public string holder;
        public decimal balance;
        private string accNo;

        private static int nxtAccNo;

        private static decimal overdraftLimit = 500;

        public Account(string name, decimal balance)
        {
            holder = name;
            this.balance = balance;
            accNo = "SA-" + (++nxtAccNo).ToString().PadLeft(4, '0');
        }
        public string GetDetails()
        {

            return $"{accNo}\t{holder}\t{balance}";
        }

        public void Deposit(decimal amt)
        {
            balance += amt;
        }
        public bool Withdraw(decimal amt)
        {
            bool result = false;
            if (amt <= this.balance + Account.overdraftLimit)
            {
                balance -= amt;
                result = true;
            }

            return result;
        }

        public static bool Transfer(Account from, Account to, decimal amt)
        {
            bool result = false;

            if (from.Withdraw(amt))
            {
                to.Deposit(amt);
                result = true;
            }

            Console.WriteLine(
                $"Transfer Successful: {(result ? "YES" : "NO")}");
            return result;
        }

    }
}
