﻿using UserUtilities;
namespace UnitTestingFun
{

    public class Program
    {
        public static void Main(string[] args)
        {
            string name = "Alice";
            int age = 30;
            string greeting = Utilities.GetGreeting(name, age);
            Console.WriteLine(greeting);
        }
    }
}
