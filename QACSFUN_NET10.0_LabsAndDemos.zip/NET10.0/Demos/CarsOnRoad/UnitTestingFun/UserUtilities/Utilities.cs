﻿namespace UserUtilities
{
    public class Utilities
    {
        public static string GetGreeting(string name = "Anon", int age = 1)
        {
            if (age < 0)
            {
                return "Age cannot be negative";
            }
            return $"Hello, {name}! You are {age} years old";
        }
    }
}
