﻿using UserUtilities;

namespace UnitTestingFunTests
{
    public class GreetingsTests
    {
        [Theory]
        [InlineData("Alice", 30, "Hello, Alice! You are 30 years old")]
        [InlineData("Alice", -1, "Age cannot be negative")]
        public void TestGetGreetingWithTypicalParameterValues(string name, int age, string expectedGreeting)
        {
            // Act
            string actualGreeting = Utilities.GetGreeting(name, age);

            // Assert
            Assert.Equal(expectedGreeting, actualGreeting);
        }


        [Fact]
        public void TestGetGreetingWithNoParameters()
        {
            // Arrange
            string expectedGreeting = "Hello, Anon! You are 1 years old";

            // Act
            string actualGreeting = Utilities.GetGreeting();

            // Assert
            Assert.Equal(expectedGreeting, actualGreeting);

        }

    }
}
