﻿using System;
using System.Collections.Generic;

class Program
{
    // Dictionary storing car details
    // reg_plate → [top_speed, current_speed, make, model]
    static Dictionary<string, (int topSpeed, int currentSpeed, string make, string model)> cars =
        new Dictionary<string, (int, int, string, string)>
    {
        { "AB12CDE", (80, 70, "Ford", "Focus") },
        { "XY34ZRT", (200, 90, "BMW", "320i") },
        { "LM56OPQ", (160, 60, "Toyota", "Corolla") },
        { "GH78JKL", (220, 100, "Audi", "A4") }
    };

    // List representing the road (index 0 = front of the road)
    static List<string> road = new List<string>
    {
        "XY34ZRT", "LM56OPQ", "GH78JKL", "AB12CDE"
    };

    static void DisplayRoad()
    {
        Console.WriteLine("\n--- Current Road ---");

        for (int i = 0; i < road.Count; i++)
        {
            string plate = road[i];
            var car = cars[plate];

            Console.WriteLine(
                $"Position {i + 1}: {plate} ({car.make} {car.model}) | Top: {car.topSpeed} | Current: {car.currentSpeed}"
            );
        }
    }

    static void AttemptOvertake()
    {
        DisplayRoad();

        Console.Write("\nEnter the registration of the car that wants to overtake: ");
        string plate = Console.ReadLine().Trim();

        if (!road.Contains(plate))
        {
            Console.WriteLine("Car not found on the road.");
            return;
        }

        int index = road.IndexOf(plate);

        if (index == 0)
        {
            Console.WriteLine("This car is already at the front and cannot overtake.");
            return;
        }

        string frontPlate = road[index - 1];

        int carTopSpeed = cars[plate].topSpeed;
        int frontCurrentSpeed = cars[frontPlate].currentSpeed;

        Console.WriteLine("\nAttempting overtake...");
        Console.WriteLine($"{plate} top speed: {carTopSpeed}");
        Console.WriteLine($"{frontPlate} current speed: {frontCurrentSpeed}");

        if (carTopSpeed > frontCurrentSpeed)
        {
            // Swap positions
            string temp = road[index - 1];
            road[index - 1] = road[index];
            road[index] = temp;

            Console.WriteLine($"{plate} successfully overtook {frontPlate}!");
        }
        else
        {
            Console.WriteLine("Overtake failed. Not enough speed.");
        }

        DisplayRoad();
    }

    static void Menu()
    {
        while (true)
        {
            Console.WriteLine("\n==== Car Road Simulation ====");
            Console.WriteLine("1. View road");
            Console.WriteLine("2. Attempt overtake");
            Console.WriteLine("3. Exit");

            Console.Write("Enter your choice: ");
            string choice = Console.ReadLine().Trim();

            if (choice == "1")
                DisplayRoad();
            else if (choice == "2")
                AttemptOvertake();
            else if (choice == "3")
            {
                Console.WriteLine("Goodbye!");
                break;
            }
            else
                Console.WriteLine("Invalid choice.");
        }
    }

    //static void Main()
    //{
    //    Menu();
    //}
}
