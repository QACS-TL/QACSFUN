﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarsOnRoadLibrary
{
    public class Road
    {
        // Dictionary storing cars
        public Dictionary<string, Car> cars = new Dictionary<string, Car>
        {
            { "AB12CDE", new Car(180, 70, "Ford", "Focus") },
            { "XY34ZRT", new Car(200, 90, "BMW", "320i") },
            { "LM56OPQ", new Car(160, 60, "Toyota", "Corolla") },
            { "GH78JKL", new Car(220, 100, "Audi", "A4") }
        };

        // Road order
        public List<string> carsOnRoad = new List<string>
        {
            "AB12CDE", "XY34ZRT", "LM56OPQ", "GH78JKL"
        };

        public string AttemptOvertake(string plate, int index, string frontPlate, Car car, Car frontCar)
        {
            if (car.TopSpeed > frontCar.CurrentSpeed)
            {
                // Swap
                carsOnRoad[index - 1] = plate;
                carsOnRoad[index] = frontPlate;

                return $"{plate} overtook {frontPlate}";
            }
            else
            {
                return "Overtake failed (insufficient speed)";
            }
        }

    }
}
