﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarsOnRoadLibrary
{
    public class Car
    {
        public int TopSpeed { get; }
        public int CurrentSpeed { get; }
        public string Make { get; }
        public string Model { get; }

        public Car(int topSpeed, int currentSpeed, string make, string model)
        {
            if (currentSpeed > topSpeed)
                throw new ArgumentException("Current speed cannot exceed top speed.");

            TopSpeed = topSpeed;
            CurrentSpeed = currentSpeed;
            Make = make;
            Model = model;
        }

        public override string ToString()
        {
            return $"{Make} {Model} | Top: {TopSpeed} | Current: {CurrentSpeed}";
        }
    }
}
