using ProjectUnderTest;

namespace UnitTestingDemo
{
    public class ArithmeticTests
    {
        [Fact]
        public void MultiplyTest()
        {
            //Arrage
            int initialValue = 5;
            long expectedResult = 120;
            long actualResult = 0;

            //Act
            actualResult = Arithmetic.GenerateFactorial(initialValue);

            //Assert
            Assert.Equal(expectedResult, actualResult);
        }
    }

    using Xunit;

    public class CalculatorTests
    {
        [Fact]
        public void Add_TwoNumbers_ReturnsSum()
        {
            // Arrange
            var calc = new Calculator();

            // Act
            var result = calc.Add(2, 3);

            // Assert
            Assert.Equal(5, result);
        }

            [Theory]
            [InlineData(2, 3, 5)]
            [InlineData(-4, -6, -10)]
            [InlineData(0, 5, 5)]
            public void Add_VariousInputs_ReturnsExpected(int a, int b, int expected)
            {
                var calc = new Calculator();
                var result = calc.Add(a, b);
                Assert.Equal(expected, result);
            }
    }

}