

namespace VariablesAndTypes
{
public class car
{
    //...
    public void Register(string name, string address, string postCode, string country)
    {
            int myAge;
            bool answer = true;
            string myName = "Michael Caine";
            int i = 0, j = 1;

            myAge = 21;
    }
}
}

