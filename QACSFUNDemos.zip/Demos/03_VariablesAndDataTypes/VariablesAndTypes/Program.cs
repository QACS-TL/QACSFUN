﻿namespace VariablesAndTypes
{
    internal class Program
    {
        static void Main(string[] args)
        {

            float f = 12.23F;
            double d = 12.23D;
            decimal m = 12.23M;

            int i = 0;
            //Creating Simple Types 
            DataTypes.CreatingSimpleTypes(); // Page 7
            DataTypes.StringDataTypes(); // Page 8

            //Creating Non Simple Types
            DataTypes.CreatingNonSimpleTypes(); // Page 10
            DataTypes.CreatingReferenceTypes(); // Pae 11

            //Variable Scope
            ScopeOfVariables.methodA(); // Page 12
            ScopeOfVariables.MethodB(); // Page 12

            //Arithmetic Operators
            DataTypes.ArithmeticPreAndPostFixOperatorExamples(); // Page 16
            DataTypes.ArithmeticOperatorsAddSubtractMultiplyDivideRemainder(); // Page 17
            DataTypes.OperatorPrecedence(); // Page 18

            //Comparisons
            DataTypes.ComparisonOperators(); // Page 20
            DataTypes.LogicalOperators(); // Page 22
            DataTypes.EqualityOperators1(); // Page 23

            //Parse
            DataTypes.Parsing(); // Page 24
            DataTypes.IntegralConversions(); // Page 26


            // ************* APPENDIX **************

            //Value Types
            DataTypes.BoolDataTypes(); // Page 35
            DataTypes.CharDataTypes(); // Page 34
            DataTypes.NullableDataTypes(); // Page 35
            DataTypes.StructDataTypes(); // Page 39
            DataTypes.EnumDataTypes(); // Page 40

            //Reference Types
            DataTypes.ClassDataTypes(); // Page 43

            //Arithmetic Operators
            DataTypes.AddAndSubtractOperatorExamples(); // Page 45
            DataTypes.MultiplyAndDivideOperatorExamples(); // Page 46
            DataTypes.RemainderOperatorExamples(); // Page 47
            DataTypes.UnaryOperatorExamples(); // Page 48

            //Comparisons
            DataTypes.LogicalOperators2(); // Page 49
            DataTypes.LogicalOperators3(); // Page 50

            //Equality Operators
            DataTypes.EqualityOperators2(); // Page 52

            //Bitwise and Shift Operators
            DataTypes.BitwiseAndShiftOperators1(); // Page 54
            DataTypes.BitwiseAndShiftOperators2(); // Page 55


        }
    }
}