﻿using System;
using System.Diagnostics.Metrics;
using static System.Net.Mime.MediaTypeNames;

namespace MethodFun
{
    internal class Program
    {   

        public static double Average(double d1, double d2)
        {
            return (d1 + d2) / 2;
        }

        public static void PrintDetails(string name, string address)
        {
            Console.WriteLine($"You are {name} and you live at {address}");
        }

        public static void PrintDetails2(string name = "Anon", string address = "")
        {
            Console.WriteLine($"You are {name} and you live at {address}");
        }

        public static bool IsHugeSalary(decimal salary)
        {
            return salary >= 100000;
        }

        public static void PrintPersonalDetails(string name, int age)
        {
            Console.WriteLine($"{name} is {age} years old,");
        }

        public static void PrintPersonalDetails(string name, int age, string hobby)
        {
            PrintPersonalDetails(name, age);
            Console.WriteLine($"Their favourite hobby is {hobby}");
        }

        public static int AddTwoNumbers(int number1, int number2) => number1 + number2;

        public static void SquareANumber(int number) => Console.WriteLine(number *= number);


        static void Main(string[] args)
        {
            // Page 8
            int i1 = 3, i2 = 9; 
            double dub1 = 3.4, dub2 = 5.8, result; 
            result = Average(2, i2);
            Console.WriteLine($"Average of {2} and {i2} is {result}");
            result = Average(i1, i2 * 3);
            Console.WriteLine($"Average of {i1} and {i2} * 3 is {result}");
            result = Average(dub1, i2);
            Console.WriteLine($"Average of {dub1} and {i2} is {result}");
            result = Average(dub1 + dub2, i1 - i2);
            Console.WriteLine($"Average of {dub1} + {dub2} and {i2} - {i1} is {result}");
            result = Average(10, Average(20, 60));
            Console.WriteLine($"Average of {10} and Average({20}, {60}) is {result}");
            Console.WriteLine(Average(10, 20)); 
            Average(dub1 * 2, dub2); // Works but where will the result go?
            //int value = Average(i1, i2);
            double value = Average(i1, i2);
            Console.WriteLine(value);

            // Page 9
            string myName = "Wallace";
            string myAddress = "92, Wallaby Street";

            PrintDetails(myName, myAddress); 
            PrintDetails("Fred", "3 " + "Smith St");

            // Page 10
            PrintDetails(name: myName, address: myAddress); 
            PrintDetails(address: "3 " + "Smith St", name: "Sadia");

            PrintDetails2(); 
            PrintDetails2(myName);
            PrintDetails2(address: myAddress);

            // Page 11
            double ave = Average(20.3, 45.5);
            Console.WriteLine($"Average of {20.3} and {45.5} is {ave}");

            bool isFatCat = IsHugeSalary(23000M);
            if (isFatCat )
                Console.WriteLine($"£{23000M} is a lot of money");
            else
                Console.WriteLine($"£{23000M} is NOT a lot of money");

            // Page 12
            Console.WriteLine("What is your name?"); 
            string name = Console.ReadLine();
            Console.WriteLine("What is your age?"); 
            string sAge = Console.ReadLine(); 
            int age = Convert.ToInt32(sAge); 
            Console.WriteLine("Hi " + name + ", next year you will be " + (age + 1));

            //Page 13
            int myAge = 21;
            string myHobby = "Stop Motion Animation";
            PrintPersonalDetails(myName, myAge);
            PrintPersonalDetails(myName, myAge, myHobby);

            // Page 14
            int val = AddTwoNumbers(i1, i2);
            Console.WriteLine($"{i1} + {i2} is {val}");

            SquareANumber(4);

            // ***************** APPENDIX *****************

            //Page 20: Extension Methods
            string s = "      The Quick Brown Dog Jumps Over The Lazy Dog       ";
            int count = s.WordCount();
            Console.WriteLine($@"The string ""{s?.Trim():string.Empty}"" contains {count} word{((count != 1)?"s":string.Empty)}"); 
        }
    }
}