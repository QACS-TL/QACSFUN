﻿using ScratchDemo;

Car c = Car.CarCreator();
c.Speed = 99999;
Console.WriteLine(c.Speed);
