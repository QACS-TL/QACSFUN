﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PropertiesAndConstructors
{
    internal class Car
    {
        public string make;
        public string model;
        public int speed;
    }
}
