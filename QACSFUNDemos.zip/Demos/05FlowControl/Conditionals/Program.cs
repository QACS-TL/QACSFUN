﻿

using Conditional;
using System.Dynamic;

namespace Conditionals
{
    public class Program
    {
        static void Main(string[] args)
        {
            //Page 06
            VotingFun.CanIVote(15); //No
            VotingFun.CanIVote(16); //No
            VotingFun.CanIVote(17); //No
            VotingFun.CanIVote(18); //Yes

            VotingFun.CanIVote(15, Country.Wales); //No
            VotingFun.CanIVote(15, Country.Scotland); //No
            VotingFun.CanIVote(15, Country.England); //No
            VotingFun.CanIVote(15, Country.NorthernIreland); //No
            VotingFun.CanIVote(16, Country.Wales); //Yes
            VotingFun.CanIVote(16, Country.Scotland); //Yes
            VotingFun.CanIVote(16, Country.England); //No
            VotingFun.CanIVote(16, Country.NorthernIreland); //No

            VotingFun.CanIVote(18, Country.Wales); //Yes
            VotingFun.CanIVote(18, Country.Scotland); //Yes
            VotingFun.CanIVote(18, Country.England); //Yes
            VotingFun.CanIVote(18, Country.NorthernIreland); //Yes

            //Page 07
            Console.WriteLine($"There are {CalendarFun.GetDaysInMonth(1)} days in month number {"February"}");
            Console.WriteLine($"There are {CalendarFun.GetDaysInMonth(3)} days in month number {"April"}");
            Console.WriteLine($"There are {CalendarFun.GetDaysInMonth(4)} days in month number {"May"}");
            Console.WriteLine($"There are {CalendarFun.GetDaysInMonth(5)} days in month number {"June"}");

            Console.WriteLine($"There are {CalendarFun.GetDaysInMonth("February")} days in month number {"February"}");
            Console.WriteLine($"There are {CalendarFun.GetDaysInMonth("March")} days in month number {"March"}");
            Console.WriteLine($"There are {CalendarFun.GetDaysInMonth("April")} days in month number {"April"}");

            //Page 08
            ParliamentsFun.GetParliament(Country.Wales);
            ParliamentsFun.GetParliament(Country.Scotland);
            ParliamentsFun.GetParliament(Country.NorthernIreland);
            ParliamentsFun.GetParliament(Country.England);
            ParliamentsFun.GetParliament((Country)6);

            //Page 09
            MeasuringFun.DisplayMeasurement(-4); // Output: Measured value is —4; too low.
            MeasuringFun.DisplayMeasurement(5); // Output: Measured value is 5.

            MeasuringFun.DisplayMeasurement(30); // Output: measured value is 30; too high.
            MeasuringFun.DisplayMeasurement(double.NaN); // Output: Failed measurement.

            //Page 11
            var country = Country.England;
            Console.WriteLine($"Country name is { country }" ) ;
            Console.WriteLine($"parliament name is {SwitchExpressionParliamentFun.GetParliament(country)}");

            //Page 13
            TernaryOperator.CoinToss();

            //Page 18
            SwitchGuardMeasuringFun.DisplayMeasurements(7, 6); // Output: First measurement is 7, second measurement is 6.
            SwitchGuardMeasuringFun.DisplayMeasurements(8, 8); // Output: Both measurements are valid and equal to 8.
            SwitchGuardMeasuringFun.DisplayMeasurements(5, -3); // Output: One or both measurements are invalid.

            //Page 19
            SwitchExpressionCaseGuard.DoTransforms();


            //Pages 21 to 23
            NullOperators.Addressing();



            // The following code tries to give a "realistic" scenario that
            // demonstrates the usefulness of null conditional and null-coalescing operators
            // However, it's pretty advanced for this point in the course. It would be better
            // to come back here after you've learnt about OO programming

            //Dog dog = null;

            //Console.WriteLine($"Will my dog bark? {dog?.Bark()}"); //null conditional operator

            //Mammal m = new Mammal();
            //Dog d = (Dog)m.GetMammal(Animal.Dog);
            //Console.WriteLine(d.Bark());

            //Cat c = (Cat)m.GetMammal(Animal.Cat);
            //Console.WriteLine(c.Meow());
            //Console.WriteLine(m.Move());

            //Mammal nm = m.GetMammal(Animal.Elephant);
            //Console.WriteLine($"{(nm == null ? "Squeak" : nm.Move())}"); // ternary operator

        }

      }

    public class Dog : Mammal
    {
        public string Bark()
        {
            return "Woof";
        }
    }

    public class Cat : Mammal
    {
        public string Meow()
        {
            return "Meow";
        }
    }

    public class Mammal
    {
        public Mammal GetMammal(Animal mammalNumber)
        {
            //switch (mammalNumber)
            //{
            //    case Animal.Dog:

            //        return new Dog();
            //    case Animal.Cat:
            //        return new Cat();
            //}
            //return null;

            Mammal mammal = mammalNumber switch
            {
                Animal.Dog => new Dog(),
                Animal.Cat => new Cat(),
                _ => null
            };
            return mammal;


        }

        public string Move()
        {
            return "Plod plod";
        }
    }

    public enum Animal
    {
        Dog,
        Cat,
        Mouse,
        Elephant
    }
}
