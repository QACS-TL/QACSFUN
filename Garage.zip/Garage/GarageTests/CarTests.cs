using Garage;

namespace GarageTests
{
    public class CarTests
    {
        [Fact]
        public void TestBasicInstantiation()
        {
            //Arrange
            Vehicle vehicle1 = new Vehicle("Ford", "Mondeo");
            Vehicle vehicle2 = new Vehicle("Vauxhall", "Corsa");

            //Act
            //vehicle1.make = "Ford";
            //vehicle.model = "Fiesta";
            
            //vehicle2.make = "Vauxhall";
            //vehicle2.model = "Corsa";
            vehicle2.Colour = "Red";

            //Assert
            Assert.Equal("Ford", vehicle1.Make);
            Assert.Equal("Mondeo", vehicle1.Model);
            Assert.Equal("Black", vehicle1.Colour);
            Assert.Equal("Vauxhall", vehicle2.Make);
            Assert.Equal("Corsa", vehicle2.Model);
            Assert.Equal("Red", vehicle2.Colour);
            Assert.Equal(2, Vehicle.NumberOfCars);
    
            // And so on
        }

        [Fact]
        public void TestAcceleration()
        {
            //Arrange
            Vehicle vehicle1 = new Vehicle();
            Vehicle vehicle2 = new Vehicle() { Make = "BMW", Model = "3 Series" };
            vehicle2.Make = "BMW";
            vehicle2.Model = "3 Series";

            //Act
            vehicle1.Accelerate(50);
            vehicle2.Accelerate(30);

            //Assert
            Assert.Equal(50, vehicle1.Speed);
            Assert.Equal(30, vehicle2.Speed);
            Assert.Equal("Ford", vehicle1.Make);
            Assert.Equal("Fiesta", vehicle1.Model);
        }

        [Fact]
        public void TestNumberOfDoorsWithAValidValue()
        {
            //Arrange
            Vehicle vehicle1 = new Vehicle();

            //Act
            vehicle1.DoorCount = 5;

            //Assert
            Assert.Equal(5, vehicle1.DoorCount);
        }

        [Fact]
        public void TestNumberOfDoorsWithANegativeValue()
        {
            //Arrange
            Vehicle vehicle1 = new Vehicle();

            //Act
            vehicle1.DoorCount = -1;
            ;

            //Assert
            Assert.Equal(0, vehicle1.DoorCount);
        }
    }
}