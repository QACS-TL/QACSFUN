﻿//using Garage;
//using System.ComponentModel.DataAnnotations;

////Vehicle v1 = new Vehicle();
////Vehicle v2 = new Vehicle();
////Vehicle v3 = new Vehicle();

//List<Vehicle> vehicles = new List<Vehicle>();
//vehicles.Add(v1);
//vehicles.Add(v2);
//vehicles.Add(v3);

//Car c = new Garage.Car() { Wheels = 4, CarEngineType = EngineType.Petrol, Colour = "Orange" };
////Car d = (Car)c;
//vehicles.Add(c);

//List<Object> objects = new List<Object>();
//objects.Add(v1);
//objects.Add(v2);
//objects.Add(v3);
//objects.Add(c);



//Console.WriteLine(v1.ToString());
//Console.WriteLine(c.ToString());

//for (int i = 0; i < vehicles.Count; i++)
//{
//    vehicles[i].Accelerate(40);
//}

//foreach(Vehicle vehicle in vehicles)
//{
//    vehicle.Brake(10);
//    //vehicle = new Vehicle();
//    Console.WriteLine(vehicle.ToString());
//}


//foreach (Object obj in objects)
//{
//    //vehicle = new Vehicle();
//    Console.WriteLine(obj.ToString());
//}

using Garage;

Car car = new Car() { Make = "Audi", Model = "A9", Speed = 100 };
Boat boat = new Garage.Boat() { Make = "Laser", Model = "Pico", Speed= 3 };
List<Vehicle> vehicles = new List<Vehicle>();
vehicles.Add(car) ;
vehicles.Add(boat);

//Console.WriteLine(car.ToString());

vehicles.Sort();

foreach (Vehicle vehicle in vehicles)
{
    Console.WriteLine(vehicle.ToString());
}
Console.WriteLine("********************");
vehicles.Sort(Vehicle.MakeComparer);

foreach (Vehicle vehicle in vehicles)
{
    Console.WriteLine(vehicle.ToString());
}

