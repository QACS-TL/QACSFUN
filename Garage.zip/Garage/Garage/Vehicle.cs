﻿namespace Garage
{
    public enum EngineType
    {
        Petrol,
        Diesel,
        Electric
    }

    public abstract class Vehicle:IComparable<Vehicle>
    {
        static private int numberOfCars = 0;

        private EngineType carEngineType;

        public EngineType CarEngineType
        {
            get { return carEngineType; }
            set { carEngineType = value; }
        }


        public Vehicle():this("Ford", "Fiesta")
        {
            
        }

        public Vehicle(string make, string model)
        {
            this.Make = make;
            this.Model = model;
            DoorCount = 4;
            numberOfCars++;
        }

        static public int NumberOfCars { get { return numberOfCars; } }

        public string Make { get; set; }
        public string Model { get; set; }

        private string colour = "Black";
        List<string> COLOURS = new(){ "Black", "Brown", "Red", "Blue", "Silver", "White" };
        public string Colour
        {
            get { return colour; }
            set { 
                if (!COLOURS.Contains(value))
                {
                    value = "Black";
                }
                colour = value; 
            }
        }

        private int doorCount;
        public int DoorCount
        {
            get { return doorCount; }
            set {
                if (value < 0)
                {
                    value = 0;
                }
                doorCount = value; 
            }
        }

        private int speed = 0;

        public int Speed
        {
            get { return speed; }
            set { speed = value; }
        }


        public bool StartEngine()
        {
            return true;
        }

        public int Accelerate(int weightOfFoot)
        {
            speed = speed + weightOfFoot;
            return speed;
        }

        public int Brake(int weightOfFoot)
        {
            speed = speed - weightOfFoot;
            return speed;
        }

        public override string ToString()
        {
            return $"I'm a Vehicle. My make is {Make} and my model is {Model}. Speed={Speed}";
        }

        public abstract void Reverse();

        public int CompareTo(Vehicle? other)
        {
            return this.Speed - other.Speed;
        }

        public abstract int MyProperty { get; set; }

        private static IComparer<Vehicle> vehicleMakeComparer = null;

        public static IComparer<Vehicle> MakeComparer
        {
            get
            {
                if (vehicleMakeComparer == null)
                {
                    VehicleMakeComparer vehicleMakeComparer = new();
                }
                return vehicleMakeComparer;
            }
        }

        private class VehicleMakeComparer : IComparer<Vehicle>
        {
            public int Compare(Vehicle? x, Vehicle? y)
            {
                return x.Make.CompareTo(y.Make);
            }
        }
    }
}
