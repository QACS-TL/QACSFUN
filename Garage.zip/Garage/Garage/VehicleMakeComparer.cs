﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Garage
{
    //public class VehicleMakeComparer : IComparer<Vehicle>
    //{
    //    public int Compare(Vehicle? x, Vehicle? y)
    //    {
    //        return x.Make.CompareTo(y.Make);
    //    }
    //}
}
