﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Garage
{
    public class Car:Vehicle
    {
        public int Wheels { get; set; }
        public bool WindowsInTheBack { get; private set; } = true;
        public override int MyProperty { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

        public void EnterLocationIntoSatNav(string postcode)
        {
            // pretend to determine route
        }

        public override void Reverse()
        {
            throw new NotImplementedException();
        }

        public override string ToString()
        {
            return $"I'm a Car. I have {Wheels} wheels. Windows in the back = {WindowsInTheBack}. {base.ToString()}";        }
    }
}
