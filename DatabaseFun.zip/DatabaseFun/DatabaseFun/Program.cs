﻿//using DatabaseFun.Models;

//using (PubsContext con = new PubsContext())
//{
//    List<Title> titles = con.Titles.ToList();

//    foreach(Title title in titles)
//    {
//        Console.WriteLine($"Title: {title.BookTitle}, Price: {title.Price:C}, YTDSales: {title.YtdSales}");
//    }
//}

//Console.WriteLine("*************************");

//using (PubsContext con = new PubsContext())
//{
//    var titles = con.Titles.Where(t => t.BookTitle.StartsWith("T"));

//    foreach (Title title in titles)
//    {
//        Console.WriteLine($"Title: {title.BookTitle}, Price: {title.Price:C}, YTDSales: {title.YtdSales}");
//    }

//    Title t = new Title() { TitleId = "XXXXXX", BookTitle = "Janet and John", Price = 2.99M, Type = "business", Pubdate = DateTime.Now };
//    //con.Titles.Add(t);

//    //con.SaveChanges();

//    con.Titles.Remove(t);

//    con.SaveChanges();  

//}


using System;
using Microsoft.Data.SqlClient; // Recommended for modern .NET apps

class Program
{
    static void Main()
    {
        // 1. Define the connection string for the 'pubs' database
        string connectionString = "Data Source=(local);Initial Catalog=pubs;Integrated Security=True;TrustServerCertificate=True";

        // 2. Use 'using' blocks to ensure resources are disposed of properly
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            string sqlQuery = "SELECT au_lname, au_fname, phone FROM authors";

            // 3. Create the SqlCommand object
            using (SqlCommand command = new SqlCommand(sqlQuery, connection))
            {
                try
                {
                    // 4. Open the connection
                    connection.Open();

                    // 5. Execute the command and get a SqlDataReader
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        Console.WriteLine("Authors in Pubs Database:");
                        Console.WriteLine("--------------------------");

                        // 6. Iterate through the results
                        while (reader.Read())
                        {
                            // Access columns by name or index
                            string lastName = reader["au_lname"].ToString();
                            string firstName = reader["au_fname"].ToString();
                            string phone = reader["phone"].ToString();

                            Console.WriteLine($"{firstName} {lastName} - {phone}");
                        }
                    }
                }
                catch (SqlException ex)
                {
                    Console.WriteLine($"SQL Error: {ex.Message}");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"General Error: {ex.Message}");
                }
            }
        }

    }
}
